"""Fixed list allocation"""


def allocz(size):
    """Alloc zeros with range"""
    return [0 for _ in range(size)]



