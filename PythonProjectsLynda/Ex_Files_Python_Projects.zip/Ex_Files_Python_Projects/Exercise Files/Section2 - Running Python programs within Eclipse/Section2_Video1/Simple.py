

print("Hello Python")





