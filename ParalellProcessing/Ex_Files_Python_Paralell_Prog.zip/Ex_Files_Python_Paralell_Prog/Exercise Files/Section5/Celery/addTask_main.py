###
#addTask.py : RUN the AddTask example with 
###

import addTask

if __name__ == '__main__':
    result = addTask.add.delay(5,5)
    
