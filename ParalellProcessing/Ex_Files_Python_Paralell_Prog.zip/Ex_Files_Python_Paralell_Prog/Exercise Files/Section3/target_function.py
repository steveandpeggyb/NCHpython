#target_function.py
def function(i):
 print ('called function in process: %s' %i)
 return
