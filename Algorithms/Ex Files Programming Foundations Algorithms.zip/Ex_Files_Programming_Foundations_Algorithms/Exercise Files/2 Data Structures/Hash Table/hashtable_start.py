# demonstrate hashtable usage


# TODO: create a hashtable all at once


# TODO: create a hashtable progressively


# TODO: try to access a nonexistent key


# TODO: replace an item


# TODO: iterate the keys and values in the dictionary
