'''
Created on Jul 31, 2016
@author: Burkhard
'''


OWM_API_KEY = '8829cb99e4783abbb9311bf665e03b22'




# Place your OpenWeatherMap key here:
# OWM_API_KEY_ = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'























