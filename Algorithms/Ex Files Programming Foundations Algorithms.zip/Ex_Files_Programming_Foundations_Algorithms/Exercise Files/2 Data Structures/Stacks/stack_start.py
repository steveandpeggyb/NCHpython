# try out the Python stack functions

# TODO: create a new empty stack


# TODO: push items onto the stack


# TODO: print the stack contents


# TODO: pop an item off the stack
