'''
Created on Aug 7, 2016
@author: Burkhard
'''




#======================
# imports
#======================
import tkinter as tk        # Python 3: "t" lower-case

# Create instance
win = tk.Tk()   

# Add a title       
win.title("Python GUI")

#======================
# Start GUI
#======================
win.mainloop()









