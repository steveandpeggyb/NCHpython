# try out the Python queue functions


# TODO: create a new empty deque object that will function as a queue


# TODO: add some items to the queue


# TODO: print the queue contents


# TODO: pop an item off the front of the queue
