print ("Hello Python Parallel Cookbook!!")
closeInput = input("Press ENTER to exit")



