'''
Created on Aug 27, 2016
@author: Burkhard
'''

GMAIL_PWD = 'PythonProjects'

