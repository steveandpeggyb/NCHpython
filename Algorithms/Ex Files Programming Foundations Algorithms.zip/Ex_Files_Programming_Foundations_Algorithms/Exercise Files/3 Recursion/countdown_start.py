# use recursion to implement a countdown counter


def countdown(x):
    return


countdown(5)
