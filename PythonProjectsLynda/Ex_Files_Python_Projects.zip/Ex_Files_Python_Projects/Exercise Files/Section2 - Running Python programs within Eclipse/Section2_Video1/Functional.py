

def say_hello():
    print("Hello Python")
    

# call the function
say_hello()

